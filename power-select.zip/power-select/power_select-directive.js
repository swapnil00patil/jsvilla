
// angular.module('myApp.version', [])

// .directive('powerSelect', ['version', function(version) {
//   return function(scope, elm, attrs) {
//     elm.text('sss');
//   };
// }]);

"use strict";
angular
    .module('myApp.version.select-directive', [])
    .directive('powerSelect', powerSelect);

function powerSelect() {
    var directive = {
        bindToController: true,
        controller: NestedCommentsController,
        controllerAs: 'vm',
        restrict: 'EA',
        scope: {
            options: "="

        },
        templateUrl: '/components/version/power-select.html'
    };

    NestedCommentsController.$inject = ['$scope'];

    /* @ngInject */
    function NestedCommentsController($scope) {
        var vm = this;
        vm.setOptions = setOptions; 
        vm.setOptions();

        $scope.$watch("vm.options", function(newVal, oldVal) {
            console.log(vm.options)
            if (newVal.length==oldVal.length) {
                return false;
            }
        }, );

        function setOptions() {
            console.log(vm.options)
        }

    }

    return directive;
}
